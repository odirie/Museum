$(document).ready(function(){

	$('.element-card').on('click', function(){

		if ( $(this).hasClass('open') ) {
			$(this).removeClass('open');
		} else {
			$('.element-card').removeClass('open');
			$(this).addClass('open');
		}

	});

});
