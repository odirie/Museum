var toogle = 0;

function myFunction() {
    if (toogle === 0) {
        console.log("Hello");
        toogleVideo();
        toogle = 1;
    } else {
        if (toogle === 1) {
            console.log("Bye");
            toogleVideo('hide');
            toogle = 0;
        }
    }

}

function toogleVideo(state) {
    // if state == 'hide', hide. Else: show video
    console.log("Inside Toogle Video");
    var div = document.getElementsByTagName("iframe")[0].contentWindow;
    console.log("Inside Toogle Video1");
    func = state == 'hide' ? 'pauseVideo' : 'playVideo';
    console.log("Inside Toogle Video3");
    console.log(state);
    div.postMessage('{"event":"command","func":"' + func + '","args":""}', '*');
};
